A Pen created at CodePen.io. You can find this one at http://codepen.io/sol0mka/pen/mICGv.

 pen for http://blog.legomushroom.com/2014/03/defining-advanced-animation-path/ post